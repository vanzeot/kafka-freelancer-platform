package com.app.shared;

public enum Skill {
    JAVA,
    PYTHON,
    JAVASCRIPT,
    DEVOPS,
    FRONTEND,
    BACKEND,
    DESIGN,
    DATA_SCIENCE
}
