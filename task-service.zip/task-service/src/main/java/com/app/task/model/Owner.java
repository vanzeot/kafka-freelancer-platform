package com.app.task.model;

import jakarta.persistence.*;

//TODO: Move this class to owner-service (decoupling)
@Entity
public class Owner {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;

}