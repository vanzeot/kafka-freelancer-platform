package com.app.task.model;

import com.app.shared.Skill;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String description;

    private Long ownerId;

    @ElementCollection
    @Enumerated(EnumType.STRING)
    private List<Skill> skills;

    private Long assignedFreelancerId;
}
