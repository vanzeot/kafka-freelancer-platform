package com.app.task.mapper;

import com.app.task.dto.TaskDTO;
import com.app.task.dto.TaskResponseDTO;
import com.app.task.model.Task;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface TaskMapper {

    Task toEntity(TaskDTO dto);

    TaskResponseDTO toDto(Task task);
}
