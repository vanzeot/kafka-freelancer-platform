package com.app.task.service;

import com.app.task.dto.TaskDTO;
import com.app.task.dto.TaskResponseDTO;
import com.app.task.kafka.TaskCreatedEvent;
import com.app.task.kafka.TaskKafkaProducer;
import com.app.task.mapper.TaskMapper;
import com.app.task.model.Task;
import com.app.task.repository.TaskRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository repository;
    private final TaskKafkaProducer kafkaProducer;
    private final TaskMapper taskMapper;

    public Task create(Task task) {
        Task created = repository.save(task);
        TaskCreatedEvent event = new TaskCreatedEvent();
        event.setId(created.getId());
        event.setTitle(created.getTitle());
        event.setDescription(created.getDescription());
        event.setOwnerId(created.getOwnerId());
        event.setSkills(created.getSkills());
        kafkaProducer.publish(event);
        return created;
    }

    public List<TaskResponseDTO> findAllDtos() {
        return repository.findAll().stream()
                .map(taskMapper::toDto)
                .toList();
    }

    public TaskResponseDTO findDtoById(Long id) {
        Task task = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Task with id " + id + " not found"));
        return taskMapper.toDto(task);
    }

    public Task update(Long id, Task updatedTask) {
        Task existing = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Task with id " + id + " not found"));

        updatedTask.setId(id);
        return repository.save(updatedTask);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new EntityNotFoundException("Task with id " + id + " not found");
        }
        repository.deleteById(id);
    }

    public Task assignFreelancer(Long taskId, Long freelancerId) {
        Task task = repository.findById(taskId).orElseThrow();
        task.setAssignedFreelancerId(freelancerId);
        return repository.save(task);
    }
}
