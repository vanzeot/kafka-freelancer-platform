package com.app.task.model;

public enum TaskCategory {
    JAVA,
    PYTHON,
    JAVASCRIPT,
    FRONTEND,
    BACKEND,
    DEVOPS
}