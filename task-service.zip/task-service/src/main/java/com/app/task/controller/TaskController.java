package com.app.task.controller;

import com.app.task.dto.TaskDTO;
import com.app.task.dto.TaskResponseDTO;
import com.app.task.mapper.TaskMapper;
import com.app.task.model.Task;
import com.app.task.service.TaskService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tasks")
@RequiredArgsConstructor
@Slf4j
public class TaskController {

    private final TaskService taskService;
    private final TaskMapper taskMapper;

    @PostMapping
    public ResponseEntity<?> create(@RequestBody TaskDTO dto) {
        log.info("Creating new task");
        try {
            var created = taskService.create(taskMapper.toEntity(dto));
            return ResponseEntity.status(HttpStatus.CREATED).body(taskMapper.toDto(created));
        } catch (Exception e) {
            log.error("Failed to create task", e);
            return ResponseEntity.internalServerError().body("Failed to create task.");
        }
    }

    @GetMapping
    public ResponseEntity<List<TaskResponseDTO>> findAll() {
        log.info("Fetching all tasks");
        return ResponseEntity.ok(taskService.findAllDtos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> get(@PathVariable Long id) {
        log.info("Getting task by id: {}", id);
        try {
            return ResponseEntity.ok(taskService.findDtoById(id));
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody TaskDTO dto) {
        log.info("Updating task with id {}: {}", id, dto);
        try {
            Task updated = taskMapper.toEntity(dto);
            Task saved = taskService.update(id, updated);
            return ResponseEntity.ok(taskMapper.toDto(saved));
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        log.info("Deleting task with id {}", id);
        try {
            taskService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @PutMapping("/{taskId}/assign/{freelancerId}")
    public ResponseEntity<?> assignFreelancer(@PathVariable Long taskId, @PathVariable Long freelancerId) {
        log.info("Assigning freelancer {} to task {}", freelancerId, taskId);
        try {
            Task task = taskService.assignFreelancer(taskId, freelancerId);
            return ResponseEntity.ok(taskMapper.toDto(task));
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error", e);
            return ResponseEntity.internalServerError().body("Internal error.");
        }

    }

}
