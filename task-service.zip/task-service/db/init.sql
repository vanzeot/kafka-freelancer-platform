DROP TABLE IF EXISTS task_skills;
DROP TABLE IF EXISTS task;
DROP TABLE IF EXISTS owner;

CREATE TABLE owner (
                       id SERIAL PRIMARY KEY,
                       name VARCHAR(255) NOT NULL,
                       email VARCHAR(255) NOT NULL
);

CREATE TABLE task (
                      id SERIAL PRIMARY KEY,
                      title VARCHAR(255) NOT NULL,
                      description TEXT,
                      owner_id INTEGER REFERENCES owner(id)
);

CREATE TABLE task_skills (
                             task_id INTEGER REFERENCES task(id),
                             skills VARCHAR(50)
);

-- OWNER

INSERT INTO owner (name, email)
VALUES ('Vanz Soft', 'comercial@vanzsoft.com.br');

INSERT INTO owner (name, email)
VALUES ('Santos Co.', 'comercial@santosco.com.br');

-- TASKS

INSERT INTO task (title, description, owner_id)
VALUES ('Kafka Back-end for Finances', 'CRUD + 8 custom endpoints using kafka and springboot.', 1);
INSERT INTO task_skills (task_id, skills) VALUES (1, 'BACKEND');

INSERT INTO task (title, description, owner_id)
VALUES ('Angular Dashboard', 'Interactive dashboard for finances.', 1);
INSERT INTO task_skills (task_id, skills) VALUES (2, 'JAVASCRIPT');
INSERT INTO task_skills (task_id, skills) VALUES (2, 'FRONTEND');

INSERT INTO task (title, description, owner_id)
VALUES ('Feature for Mobile APP using IONIC', 'Develop a custom date-picker component.', 2);
INSERT INTO task_skills (task_id, skills) VALUES (3, 'JAVASCRIPT');
